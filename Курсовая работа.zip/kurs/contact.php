<!DOCTYPE html>
<html lang="ru">
  <head>
    <title>Контакты</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="styless.css">
  
</head>
<header>
	<div>
	<div id="rectangle">
	
		<a href="kompaniya.php" class="button1">О компании</a>
		<a href="contact.php" button class="button2">Контакты</a>
		<a href="index.php" button class="button3">Главная</a>
        
	    </div>
	
	
</div>
</header>
<body>
	<div class="prok" align="center">
<div id="square">
	<h1>Контактная информация</h1>
	<div align="left">
				
	<h2>Адрес</h2>
	<p>Компания HOTEL MOSCOW  является аффилированной компанией HOTEL Entertainment Inc. <br>и зарегистрирована под идентификационным номером SIREN 489 952 457 RCS Versailles</p>
    <p>145 rue Yves le Coz  78000 Versailles  France </p>
    
	<h3>Связаться с нами</h3>
	<p>VAT Reg. No. (FR): 489 952 457 VAT Reg. No.</p>
    <p>(EU): FR 87 489 952 457</p>
	<h4>Почтовый адрес</h4>
	<p>HOTEL Entertainment SAS</p> 
<p>TSA 60001</p>
<p>78008 Versailles CEDEX</p>
<p>France</p>
<h5>Посещение офиса</h5>
<p>В настоящий момент для посещений открыт только главный офис HOTEL в Ирвайне (США, штат Калифорния). Туры для публики проводятся раз в месяц, количество мест ограничено. Если вы хотите прийти — загляните, пожалуйста, в раздел вопросов и ответов (на английском языке) и напишите нам по адресу hotelmoscow@gmail.com (по-английски).</p>


</div>
</div>
</div>


</body>
</html>